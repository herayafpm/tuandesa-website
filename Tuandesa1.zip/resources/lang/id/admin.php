<?php

return [
  'datamaster' => 'Data Master',
  'dashboard' => 'Dashboard',
  'logout' => 'Keluar',
  'profile' => 'Profil',
  'datausers' => 'Data User',
  'dataroles' => 'Data Role',
  'dataprofiledesas' => 'Data Profile Desa',
  'aduans' => 'Aduan',
  'dataaduans' => 'Data Aduan',
  'jenisaduans' => 'Jenis Aduan',
  'beritas' => 'Berita',
  'databeritas' => 'Data Berita',
  'jenisberitas' => 'Jenis Berita',
  'pelayanans' => 'Pelayanan',
  'datapelayanans' => 'Data Pelayanan',
  'jenispelayanans' => 'Jenis Pelayanan',
  'laporanpelayanan' => 'Laporan Pelayanan',
  'bantuans' => 'Bantuan',
  'databantuans' => 'Data Bantuan',
  'jenisbantuans' => 'Jenis Bantuan',
  'soaljawabans' => 'Soal & Jawaban',
  'zakats' => 'Zakat',
  'datazakats' => 'Data Zakat',
  'jeniszakats' => 'Jenis Zakat',
  
  'deletecurrentuser'=>'Menghapus akun yang saat ini digunakkan tidak depebolehkan :(',
  'deleteddata'=>'data terhapus',
  'deleteddataerror'=>'data tidak bisa dihapus'
];