<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>Version</b> {{config('app.version')}}
  </div>
<strong>Copyright &copy; 2020-2020 <a href="{{url('')}}">{{config('app.name')}}</a> <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
  reserved.
</footer>