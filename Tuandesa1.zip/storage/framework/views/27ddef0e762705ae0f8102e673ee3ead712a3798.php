
<?php $__env->startSection('headTitle',__('admin.dataroles')); ?>
<?php $__env->startSection('content'); ?>
    <div class="row m-2">
      <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-12">
        <div class="card">
          <!-- /.card-header -->
          <div class="card p-2">
            <div class="card-header">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_roles')): ?>
            <div><a href="<?php echo e(route('roles.create')); ?>" class="btn btn-sm btn-success pull-right"> <i class="fa fa-fw fa-plus"></i> New</a></div>
              <?php endif; ?>
            </div>
            <div class="card-body table-responsive p-0">
              <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php echo Form::model($role, ['method' => 'PUT', 'route' => ['roles.update',  $role->id ], 'class' => 'm-b']); ?>


                  <?php if($role->name === 'Super Admin'): ?>
                      <?php echo $__env->make('admin.shared._permissions', [
                                    'id' => $role->id,
                                    'title' => $role->name .' Permissions',
                                    'options' => ['disabled'] ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php else: ?>
                      <?php echo $__env->make('admin.shared._permissions', [
                                    'id' => $role->id,
                                    'title' => $role->name .' Permissions',
                                    'model' => $role ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php endif; ?>

                  <?php echo Form::close(); ?>


              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p>No Roles defined, please run <code>php artisan db:seed</code> to seed some dummy data.</p>
              <?php endif; ?>
            </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
      <!-- /.card -->

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>