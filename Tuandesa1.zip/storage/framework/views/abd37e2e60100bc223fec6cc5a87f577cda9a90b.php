
<?php
    $formTitle = !empty($soaljawaban)?'Update':'New'
?>
<?php $__env->startSection('headTitle',$formTitle.' '.__('admin.soaljawabans').' '.$soaljawaban->soal); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1><?php echo e($formTitle); ?> <?php echo e(__('admin.soaljawabans')); ?> <?php echo e($soaljawaban->soal); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/soaljawabans')); ?>"><?php echo e(__('admin.soaljawabans')); ?></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if(!empty($jawaban)): ?>
                  <?php echo Form::model($jawaban, ['url' => 'admin/soaljawabans/'.$soaljawaban->id.'/edit-jawaban/'.$jawaban->id,'method' => 'PUT']); ?>

                  <?php echo Form::hidden('id'); ?>

              <?php else: ?>
                  <?php echo Form::open(['url' => 'admin/soaljawabans/'.$soaljawaban->id.'/add-jawaban']); ?>

              <?php endif; ?>
              <?php echo Form::hidden('soal_jawaban_id', $soaljawaban->id); ?>

              <div class="form-group">
                <?php echo Form::label('jawaban', 'Jawaban'); ?>

                <?php echo Form::text('jawaban', null, ['class' => 'form-control','placeholder' => 'Jawaban']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('nilai', 'Nilai'); ?>

                <select class="form-control" name="nilai" id="nilai">
                  <option value="">--Pilih Nilai--</option>
                  <?php for($i = 1; $i <= $jumlahnilai; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php if(!empty($jawaban) &&$i == $jawaban->nilai): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="<?php echo e(route('soaljawabans.edit',$soaljawaban->id)); ?>" class="btn btn-secondary" >back</a>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/soaljawabans/form_jawaban.blade.php ENDPATH**/ ?>