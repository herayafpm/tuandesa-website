
<?php $__env->startSection('headTitle',__('admin.jenispelayanans')); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('vendor/adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">   
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e(__('admin.jenispelayanans')); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><?php echo e(__('admin.jenispelayanans')); ?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="row">
          <div class="col-12">
            <div class="card">
              <!-- /.card-header -->
              <div class="card p-2">
                <div class="card-header">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_jenispelayanans')): ?>
                  <div><a class="btn btn-primary" href="<?php echo e(url('admin/jenispelayanans/create')); ?>">Add New</a></div>
                  <?php endif; ?>
                  <div class="card-tools">
                    <div class="input-group input-group-sm">
                      <?php echo Form::open(['url' => route('jenispelayanans.index'), 'method' => 'GET']); ?>

                        <div class="row">
                          <div class="col">
                            <?php echo Form::select('orderBy',  ['id' => 'id','created_at' => 'Dibuat','name' => 'Nama'],app('request')->input('orderBy'),['placeholder' => '--Pilih Order By--','class' => 'form-control']); ?>

                          </div>
                          <div class="col">
                            <?php echo Form::select('order',  ['asc' => 'ASC','desc' => 'DESC'],app('request')->input('order'),['placeholder' => '--Pilih Order--','class' => 'form-control']); ?>

                          </div>
                          <div class="col-4">
                            <div class="input-group">
                              <div class="input-group-prepend">
                                <span class="input-group-text">
                                  <i class="far fa-calendar-alt"></i>
                                </span>
                              </div>
                              <input name="date" type="text" class="form-control float-right" id="daterange" value=<?php echo e(urldecode(app('request')->input('date'))); ?>>
                            </div>
                          </div>
                          <div class="col">
                            <input type="text" name="search" class="form-control float-right" placeholder="Search" value="<?php echo e(app('request')->input('search')); ?>">
                          </div>
                          <div class="col">
                            <button type="submit" class="btn btn-primary">Proses</button>
                          </div>
                        </div>
                      <?php echo Form::close(); ?>

                    </div>
                  </div>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover table-fixed-head">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_jenispelayanans', 'delete_jenispelayanans')): ?>
                        <th>Action</th>
                        <?php endif; ?>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $jenispelayanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenispelayanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($jenispelayanan->id); ?></td>
                          <td><?php echo e($jenispelayanan->name); ?></td>
                          <td><?php echo e($jenispelayanan->created_at); ?></td>
                          <td><?php echo e($jenispelayanan->updated_at); ?></td>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_jenispelayanans', 'delete_jenispelayanans')): ?>
                          <td class="row w-100">
                          <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(url('admin/jenispelayanans/'.$jenispelayanan->id.'/edit')); ?>" role="button">
                            <i class="fa fa-fw fa-pen" aria-hidden="true"></i>
                            Edit</a>
                          <?php echo Form::open(['url' => 'admin/jenispelayanans/'.$jenispelayanan->id,'class'=> 'delete']); ?>

                          <?php echo Form::hidden('_method', 'DELETE'); ?>

                            <button type="submit" class="btn btn-danger btn-sm">
                              <i class="fa fa-fw fa-trash" aria-hidden="true"></i>Delete
                            </button>
                          <?php echo Form::close(); ?>

                          </td>
                          <?php endif; ?>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                            <td colspan="5">No Records</td>
                          </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                  
                </div>
              </div>
              <div class="card-footer">
                <?php echo e($jenispelayanans->links()); ?>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(URL::asset('vendor/adminlte/plugins/moment/moment.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('vendor/adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script>
  var starDate;
  var endDate;
  $(function(){
    var date = "<?php echo e(app('request')->input('date')); ?>";
    if(date != null){
      date = date.split(" - ")
     startDate = date[0];
     endDate = date[1];
    }
    $('#daterange').daterangepicker({
      locale: {
        format: 'YYYY-MM-DD'
      },
      startDate: (startDate != null)?starDate:"<?php echo e(date('Y-M-d')); ?>",
      endDate: endDate
    })
  })
  
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/jenispelayanans/index.blade.php ENDPATH**/ ?>