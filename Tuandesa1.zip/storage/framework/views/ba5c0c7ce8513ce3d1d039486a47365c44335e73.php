
<?php $__env->startSection('headTitle',__('admin.profile')); ?>
<?php
  $status = $user->getRoleNames()[0];
  $ajuan = false;
  if($status == 'User' || $status == 'Amil'){
    $ajuan = true;
  }
?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e(__('admin.profile')); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><?php echo e(__('admin.profile')); ?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                <img class="profile-user-img img-fluid img-circle" src="<?php echo e(url($user->photo)); ?>" alt="User profile picture">
                </div>

              <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>
              <p class="text-muted text-center"><?php echo e($user->username); ?></p>

              <p class="text-muted text-center"><?php echo e($user->getRoleNames()[0]); ?></p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                  <b>Aduan</b> <a class="float-right"><?php echo e($user->aduans->count()); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Pelayanan</b> <a class="float-right"><?php echo e($user->pelayanans->count()); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Bantuan</b> <a class="float-right"><?php echo e($user->pelayanans->count()); ?></a>
                  </li>
                </ul>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#aduan" data-toggle="tab">Aduan Saya</a></li>
                  <li class="nav-item"><a class="nav-link" href="#pelayanan" data-toggle="tab">Pelayanan Saya</a></li>
                  <li class="nav-item"><a class="nav-link" href="#bantuan" data-toggle="tab">Bantuan Saya</a></li>
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_zakatamils')): ?>
                  <li class="nav-item"><a class="nav-link" href="#zakat" data-toggle="tab">Zakat</a></li>
                  <?php endif; ?>
                  <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Settings</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="aduan">
                    <?php if($ajuan): ?>
                    <a name="" id="" class="btn btn-primary m-2" href="<?php echo e(url('admin/profile/aduan')); ?>" role="button">Ajukan Aduan</a>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $user->aduans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aduan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="post">
                          <div class="user-block">
                          <img class="img-circle img-bordered-sm" src="<?php echo e(url($aduan->user->photo)); ?>" alt="user image">
                            <span class="username">
                            <a href="#"><?php echo e($aduan->user->name); ?></a>
                            </span>
                          <span class="description">Diajukan pada - <?php echo e($aduan->updated_at); ?></span>
                          </div>
                          <p class="text-muted">Status: 
                            <?php if((bool) $aduan->status): ?>
                              <span class="text-success"><?php echo e($aduan->getStatus($aduan->status)); ?></span>
                            <?php else: ?>
                              <span class="text-info"><?php echo e($aduan->getStatus($aduan->status)); ?></span>
                            <?php endif; ?>
                          </p>
                          <!-- /.user-block -->
                          <p>
                           <?php echo e($aduan->komentar); ?>

                          </p>
                          <div class="row">
                            <p>
                              <?php echo Form::open(['url' => ['admin/profile/likeaduan',$aduan->id]]); ?>

                              <?php if(sizeof($aduan->likes->where('user_id',auth()->user()->id)) === 0): ?>
                                <button tipe="submit" class="btn btn-link text-sm float-left" href="#" role="button"><i class="far fa-thumbs-up mr-1"></i> Like (<?php echo e($aduan->likes->count()); ?>)</button>
                              <?php else: ?>
                                <button tipe="submit" class="btn btn-link link-black text-sm float-left" href="#" role="button"><i class="far fa-thumbs-up mr-1"></i> Like (<?php echo e($aduan->likes->count()); ?>)</button>
                              <?php endif; ?>
                              <?php echo Form::close(); ?>

                            </p>
                          </div>
                          <div class="row">
                            <div class="col">
                              <div class="card card-sucress cardutline direct-chat direct-chat-success collapsed-card">
                              <div class="card-header">
                                <h3 class="card-title">Komentar Aduan</h3>

                                <div class="card-tools">
                                  <span data-toggle="tooltip" title="<?php echo e($aduan->comments->count()); ?> New komentar" class="badge bg-success"><?php echo e($aduan->comments->count()); ?></span>
                                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i>
                                  </button>
                                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                                  </button>
                                </div>
                              </div>
                              <!-- /.card-header -->
                              <div class="card-body p-2" style="display: none;">

                                <!-- Contacts are loaded here -->
                                <?php $__currentLoopData = $aduan->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="direct-chat-msg <?php if($item->user->id != auth()->user()->id): ?> right <?php endif; ?>">
                                    <div class="direct-chat-infos clearfix">
                                      <span class="direct-chat-name float-right">
                                        <?php if($item->user->id == auth()->user()->id): ?>
                                        <?php echo Form::open(['url' => 'admin/profile/komentaraduan/'.$item->id,'class'=> 'delete']); ?>

                                        <?php echo Form::hidden('_method', 'DELETE'); ?>

                                          <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fa fa-fw fa-trash" aria-hidden="true"></i>
                                          </button>
                                        <?php echo Form::close(); ?>

                                        Saya
                                        <?php else: ?>
                                        <?php echo e($item->user->name); ?>

                                        <?php endif; ?>
                                      </span>
                                    <span class="direct-chat-timestamp float-left"><?php echo e($item->created_at); ?> / <?php echo e($item->updated_at); ?></span>
                                    </div>
                                    <!-- /.direct-chat-infos -->
                                    <img class="direct-chat-img" src="<?php echo e(url($item->user->photo)); ?>" alt="Message User Image">
                                    <!-- /.direct-chat-img -->
                                    <div class="direct-chat-text">
                                      <?php echo e($item->komentar); ?>

                                    </div>
                                    <!-- /.direct-chat-text -->
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- /.direct-chat-pane -->
                              </div>
                              <!-- /.card-body -->
                              <div class="card-footer" style="display: none;">
                                <?php echo Form::open(['url' => ['admin/profile/komentaraduan',$aduan->id]]); ?>

                                  <div class="input-group">
                                     <?php echo Form::text('komentar', null, ['class' => 'form-control','placeholder' => 'Tuliskan komentar']); ?>

                                    <span class="input-group-append">
                                      <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane fa-fw" aria-hidden="true"></i> Kirim</button>
                                    </span>
                                  </div>
                                <?php echo Form::close(); ?>

                              </div>
                              <!-- /.card-footer-->
                            </div>
                            </div>
                            
                          </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <div class="row">
                        <h3 class="text-center">Belum ada aduan yang diajukan</h3>
                      </div>
                    <?php endif; ?>
                    <!-- /.post -->
                  </div>
                  <div class="tab-pane" id="pelayanan">
                    <?php if($ajuan): ?>
                    <a name="" id="" class="btn btn-primary m-2" href="<?php echo e(url('admin/profile/pelayanan')); ?>" role="button">Ajukan Pelayanan</a>
                    <?php endif; ?>
                    <!-- Post -->
                    <?php $__empty_1 = true; $__currentLoopData = $user->pelayanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelayanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="post">
                          <div class="user-block">
                          <img class="img-circle img-bordered-sm" src="<?php echo e(url($pelayanan->user->photo)); ?>" alt="user image">
                            <span class="username">
                            <a href="#"><?php echo e($pelayanan->user->name); ?></a>
                            </span>
                          <span class="description">Diajukan pada - <?php echo e($pelayanan->updated_at); ?></span>
                          </div>
                          <p class="text-muted">Status: 
                            <?php if((bool) $pelayanan->status): ?>
                              <span class="text-success"><?php echo e($pelayanan->getStatus($pelayanan->status)); ?></span>
                            <?php else: ?>
                              <span class="text-info"><?php echo e($pelayanan->getStatus($pelayanan->status)); ?></span>
                            <?php endif; ?>
                          </p>
                          <!-- /.user-block -->
                          <p>
                           <?php echo e($pelayanan->komentar); ?>

                          </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <div class="row">
                        <h3 class="text-center">Belum ada pelayanan yang diajukan</h3>
                      </div>
                    <?php endif; ?>
                    <!-- /.post -->
                  </div>
                  <div class="tab-pane" id="bantuan">
                    <!-- Post -->
                    <?php $__empty_1 = true; $__currentLoopData = $user->pelayanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelayanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="post">
                          <div class="user-block">
                          <img class="img-circle img-bordered-sm" src="<?php echo e(url($pelayanan->user->photo)); ?>" alt="user image">
                            <span class="username">
                            <a href="#"><?php echo e($pelayanan->user->name); ?></a>
                            </span>
                          <span class="description">Diajukan pada - <?php echo e($pelayanan->updated_at); ?></span>
                          </div>
                          <p class="text-muted">Status: 
                            <?php if((bool) $pelayanan->status): ?>
                              <span class="text-success"><?php echo e($pelayanan->getStatus($pelayanan->status)); ?></span>
                            <?php else: ?>
                              <span class="text-info"><?php echo e($pelayanan->getStatus($pelayanan->status)); ?></span>
                            <?php endif; ?>
                          </p>
                          <!-- /.user-block -->
                          <p>
                           <?php echo e($pelayanan->komentar); ?>

                          </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <div class="row">
                        <h3 class="text-center">Belum ada pelayanan yang diajukan</h3>
                      </div>
                    <?php endif; ?>
                    <!-- /.post -->
                  </div>
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_zakatamils')): ?>
                  <div class="tab-pane" id="zakat">
                    <!-- Post -->
                    <?php $__empty_1 = true; $__currentLoopData = $zakats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zakat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="post">
                          <div class="user-block">
                            <span class="username">
                            <a href="<?php echo e(route('profile.zakat',$zakat->id)); ?>"><?php echo e($zakat->name); ?></a>
                            </span>
                          <span class="description">Dimulai pada - <?php echo e(\Carbon\Carbon::parse($zakat->start)->translatedFormat('d F Y H:i:s')); ?></span>
                          <span class="description">
                            Berakhir pada - <?php echo e(\Carbon\Carbon::parse($zakat->end)->translatedFormat('d F Y H:i:s')); ?> / <?php echo e(\Carbon\Carbon::parse($zakat->end)->diffForHumans()); ?>

                          </span>
                          </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <div class="row">
                        <h3 class="text-center">Belum ada zakat yang dijalankan</h3>
                      </div>
                    <?php endif; ?>
                    <!-- /.post -->
                  </div>
                  <?php endif; ?>
                  <!-- /.tab-pane -->
                  
                  <div class="tab-pane" id="settings">
                      <?php echo Form::model($user, ['url' => ['admin/profile'],'method' => 'PUT','class' => 'form-horizontal']); ?>

                      <?php echo Form::hidden('id'); ?>

                      <?php echo Form::hidden('name'); ?>

                      <?php echo Form::hidden('username'); ?>

                      <?php echo Form::hidden('address'); ?>

                      <?php echo Form::hidden('roles'); ?>

                      <div class="form-group row">
                        <?php echo Form::label('email', 'Email'); ?>

                        <?php echo Form::text('email', null, ['class' => 'form-control','placeholder' => 'Email']); ?>

                      </div>
                      <div class="form-group row">
                        <?php echo Form::label('ttl', 'Tempat Tanggal Lahir'); ?>

                        <?php echo Form::text('ttl', null, ['class' => 'form-control','placeholder' => 'Tempat Tanggal Lahir']); ?>

                      </div>
                      <div class="form-group row">
                        <?php echo Form::label('no_hp', 'NO HP'); ?>

                        <?php echo Form::text('no_hp', null, ['class' => 'form-control','placeholder' => 'NO HP']); ?>

                      </div>
                      <div class="form-group row">
                       <?php echo Form::label('password', 'Password'); ?>

                       <?php echo Form::input('password', 'password', null,['class' => 'form-control','placeholder' => 'Isikan untuk validasi']); ?>

                      </div>
                      <div class="form-footer pt-2 border-top">
                        <button type="submit" class="btn btn-primary">Save</button>
                      </div>
                      <?php echo Form::close(); ?>

                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/profile.blade.php ENDPATH**/ ?>