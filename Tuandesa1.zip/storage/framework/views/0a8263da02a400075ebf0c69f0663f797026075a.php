
<?php
    $formTitle = !empty($profiledesa)?'Update':'New'
?>
<?php $__env->startSection('headTitle',__('admin.dataprofiledesas').' '.$formTitle); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e($formTitle); ?> Profile Desa</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/profiledesas')); ?>">Profil Desa</a></li>
              <li class="breadcrumb-item active">Profile Desa</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if(!empty($profiledesa)): ?>
                  <?php echo Form::model($profiledesa, ['url' => ['admin/profiledesas',$profiledesa->id],'method' => 'PUT']); ?>

                  <?php echo Form::hidden('id'); ?>

              <?php else: ?>
                  <?php echo Form::open(['url' => 'admin/profiledesas']); ?>

              <?php endif; ?>
              <div class="form-group">
                <?php echo Form::label('judul', 'Judul'); ?>

                <?php echo Form::text('judul', null, ['class' => 'form-control','placeholder' => 'Judul']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('description', 'Description'); ?>

                <?php echo Form::textarea('description', null, ['class' => 'form-control','placeholder' => 'Description']); ?>

              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <?php if(!empty($profiledesa)): ?>
            <div class="col-6">
            <div class="card">
              <!-- /.card-header -->
              <div class="card p-2">
                <div class="card-header">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_profiledesas')): ?>
                  <div><a class="btn btn-primary" href="<?php echo e(url('admin/profiledesas/'.$profiledesa->id.'/add-image')); ?>">Add New</a></div>
                  <?php endif; ?>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover table-fixed-head">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Image</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_profiledesas', 'delete_profiledesas')): ?>
                        <th>Action</th>
                        <?php endif; ?>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $profiledesa->profile_desa_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($image->id); ?></td>
                          <td>
                            <img style="width:150px" src="<?php echo e(url($image->path)); ?>">
                          </td>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_profiledesas', 'delete_profiledesas')): ?>
                          <td class="row w-100">
                          <?php echo Form::open(['url' => 'admin/profiledesas/images/'.$image->id,'class'=> 'delete']); ?>

                          <?php echo Form::hidden('_method', 'DELETE'); ?>

                            <button type="submit" class="btn btn-danger btn-sm">
                              <i class="fa fa-fw fa-trash" aria-hidden="true"></i>Delete
                            </button>
                          <?php echo Form::close(); ?>

                          </td>
                          <?php endif; ?>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                            <td colspan="5">No Records</td>
                          </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                  
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        <?php endif; ?>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/profiledesas/form.blade.php ENDPATH**/ ?>