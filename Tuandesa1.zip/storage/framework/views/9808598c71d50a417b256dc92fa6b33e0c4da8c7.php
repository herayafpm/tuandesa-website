
<?php
    $formTitle = !empty($berita)?'Update':'New'
?>
<?php $__env->startSection('headTitle',__('admin.databeritas').' '.$formTitle); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e($formTitle); ?> <?php echo e(__('admin.databeritas')); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/beritas')); ?>"><?php echo e(__('admin.databeritas')); ?></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if(!empty($berita)): ?>
                  <?php echo Form::model($berita, ['url' => ['admin/beritas',$berita->id],'method' => 'PUT']); ?>

                  <?php echo Form::hidden('id'); ?>

              <?php else: ?>
                  <?php echo Form::open(['url' => 'admin/beritas', 'enctype' => 'multipart/form-data']); ?>

              <?php endif; ?>
              <?php echo Form::hidden('user_id', Auth::user()->id); ?>

              <div class="form-group">
                <?php echo Form::label('jenis_berita', 'Jenis berita'); ?>

                <?php echo Form::select('jenis_berita_id', $jenisberitas,null, ['class' => 'form-control','id' => 'jenis_berita','placeholder' => '--Pilih Jenis berita--']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('komentar', 'Komentar'); ?>

                <?php echo Form::textarea('komentar', null, ['class' => 'form-control','placeholder' => 'Komentar']); ?>

              </div>
              <?php if(empty($berita)): ?>
              <div class="form-group">
                <?php echo Form::label('image', 'Lampiran'); ?>

                <?php echo Form::file('image[]', ['class' => 'form-control-file','placeholder' => 'Lampiran','multiple' => true]); ?>

              </div>
              <?php endif; ?>
              <?php if(!empty($berita)): ?>
              <div class="form-group">
                <?php echo Form::label('status', 'Status'); ?>

                <?php echo Form::select('status', $statuses,$berita->status, ['class' => 'form-control']); ?>

              </div>
              <?php endif; ?>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <?php if(!empty($berita)): ?>
            <div class="col-6">
            <div class="card">
              <!-- /.card-header -->
              <div class="card p-2">
                <div class="card-header">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_beritas')): ?>
                  <div><a class="btn btn-primary" href="<?php echo e(url('admin/beritas/'.$berita->id.'/add-image')); ?>">Add New</a></div>
                  <?php endif; ?>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover table-fixed-head">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Image</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_beritas', 'delete_beritas')): ?>
                        <th>Action</th>
                        <?php endif; ?>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $berita->berita_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($image->id); ?></td>
                          <td>
                            <img style="width:150px" src="<?php echo e(url($image->path)); ?>">
                          </td>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_beritas', 'delete_beritas')): ?>
                          <td class="row w-100">
                          <?php echo Form::open(['url' => 'admin/beritas/images/'.$image->id,'class'=> 'delete']); ?>

                          <?php echo Form::hidden('_method', 'DELETE'); ?>

                            <button type="submit" class="btn btn-danger btn-sm">
                              <i class="fa fa-fw fa-trash" aria-hidden="true"></i>Delete
                            </button>
                          <?php echo Form::close(); ?>

                          </td>
                          <?php endif; ?>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                            <td colspan="5">No Records</td>
                          </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                  
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        <?php endif; ?>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/beritas/form.blade.php ENDPATH**/ ?>