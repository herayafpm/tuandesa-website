
<?php
    $formTitle = !empty($jenisbantuan)?'Update':'New'
?>
<?php $__env->startSection('headTitle',__('admin.jenisbantuans').' '.$formTitle); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e($formTitle); ?> Profile Desa</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/jenisbantuans')); ?>">Jenis Aduan</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if(!empty($jenisbantuan)): ?>
                  <?php echo Form::model($jenisbantuan, ['url' => ['admin/jenisbantuans',$jenisbantuan->id],'method' => 'PUT']); ?>

                  <?php echo Form::hidden('id'); ?>

              <?php else: ?>
                  <?php echo Form::open(['url' => 'admin/jenisbantuans']); ?>

              <?php endif; ?>
              <div class="form-group">
                <?php echo Form::label('name', 'Name'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control','placeholder' => 'Name']); ?>

              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="<?php echo e(route('jenisbantuans.index')); ?>" class="btn btn-secondary" >back</a>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/jenisbantuans/form.blade.php ENDPATH**/ ?>