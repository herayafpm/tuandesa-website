
<?php $__env->startSection('headTitle',__('admin.databeritas').' Image'); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Tambah Image Berita</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo Form::open(['url' => 'admin/beritas/images/'.$beritaId, 'method' => "POST", 'enctype' => 'multipart/form-data']); ?>

              <div class="form-group">
                <?php echo Form::label('image', 'Berita Image'); ?>

                <?php echo Form::file('image[]', ['class' => 'form-control-file','placeholder' => 'Berita Image','multiple' => true]); ?>

              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              <a name="" id="" class="btn btn-secondary" href="<?php echo e(url('admin/beritas/'.$beritaId.'/edit')); ?>" role="button">Back</a>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/beritas/form_image.blade.php ENDPATH**/ ?>