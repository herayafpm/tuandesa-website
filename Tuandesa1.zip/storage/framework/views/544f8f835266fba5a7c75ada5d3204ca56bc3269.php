
<?php $__env->startSection('headTitle',__('admin.dataroles')); ?>
<?php $__env->startSection('content'); ?>
    <div class="row m-2">
      <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-12">
        <div class="card p-2">
            <div class="card-header">
              Add new Roles
            </div>
            <div class="card-body table-responsive p-0">
              <?php echo Form::open(['url' => route('roles.store'),'method' => 'post']); ?>

              <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                  <?php echo Form::label('name', 'Name'); ?>

                  <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Role Name']); ?>

                  <?php if($errors->has('name')): ?> <p class="help-block"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
              </div>
                <a class="btn btn-secondary" href="<?php echo e(route('roles.index')); ?>" role="button">Back</a>
              <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

            </div>
        <!-- /.card -->
      </div>
    </div>
      <!-- /.card -->

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/roles/form.blade.php ENDPATH**/ ?>