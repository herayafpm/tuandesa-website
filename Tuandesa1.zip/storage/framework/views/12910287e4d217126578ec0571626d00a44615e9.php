
<?php $__env->startSection('headTitle',"Pengajuan Aduan"); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Pengajuan Aduan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/profile')); ?>">Back</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo Form::open(['url' => 'admin/profile/aduan', 'enctype' => 'multipart/form-data']); ?>

              <?php echo Form::hidden('user_id', auth()->user()->id); ?>

              <div class="form-group">
                <?php echo Form::label('jenis_aduan', 'Jenis Aduan'); ?>

                <?php echo Form::select('jenis_aduan_id', $jenisaduans,null, ['class' => 'form-control','id' => 'jenis_aduan','placeholder' => '--Pilih Jenis Aduan--']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('komentar', 'Komentar'); ?>

                <?php echo Form::textarea('komentar', null, ['class' => 'form-control','placeholder' => 'Komentar']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('image', 'Lampiran'); ?>

                <?php echo Form::file('image[]', ['class' => 'form-control-file','placeholder' => 'Lampiran','multiple' => true]); ?>

              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/profiles/form_aduan.blade.php ENDPATH**/ ?>