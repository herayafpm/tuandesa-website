<div id="accordion">
    <div class="card card-success mt-1">
        <div class="card-header" id="heading<?php echo e($id); ?>">
        <h3 class="card-title">
            <a class="btn btn-link" data-toggle="collapse" data-target="#collapse<?php echo e($id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($id); ?>">
            <?php echo e($title); ?> <?php echo isset($user) ? '<span class="text-danger">(' . $user->getDirectPermissions()->count() . ')</span>' : ''; ?>

            </a>
        </h3>
        <!-- /.card-tools -->
        <div class="card-tools">
            
        </div>
        </div>
        <!-- /.card-header -->
        <div id="collapse<?php echo e($id); ?>" class="collapse" aria-labelledby="heading<?php echo e($id); ?>" data-parent="#accordion">
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $per_found = null;

                            if( isset($role) ) {
                                $per_found = $role->hasPermissionTo($perm->name);
                            }

                            if( isset($user)) {
                                $per_found = $user->hasDirectPermission($perm->name);
                            }
                        ?>

                        <div class="col-md-3">
                            <div class="checkbox">
                                <label class="<?php echo e(Str::contains($perm->name, 'delete') ? 'text-danger' : ''); ?>">
                                    <?php echo Form::checkbox("permissions[]", $perm->name, $per_found, isset($options) ? $options : []); ?> <?php echo e($perm->name); ?>

                                </label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_roles')): ?>
                    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <?php endif; ?>
            </div>
        </div>

        <!-- /.card-body -->
    </div>
</div><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/shared/_permissions.blade.php ENDPATH**/ ?>