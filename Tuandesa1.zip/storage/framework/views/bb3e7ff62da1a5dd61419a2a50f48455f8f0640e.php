
<?php
    $formTitle = !empty($soaljawaban)?'Update':'New'
?>
<?php $__env->startSection('headTitle',$formTitle.' '.__('admin.soaljawabans').' '.$jenisbantuan->name); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1><?php echo e($formTitle); ?> <?php echo e(__('admin.soaljawabans')); ?> <?php echo e($jenisbantuan->name); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/soaljawabans')); ?>"><?php echo e(__('admin.soaljawabans')); ?></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if(!empty($soaljawaban)): ?>
                  <?php echo Form::model($soaljawaban, ['url' => ['admin/soaljawabans',$soaljawaban->id],'method' => 'PUT']); ?>

                  <?php echo Form::hidden('id'); ?>

              <?php else: ?>
                  <?php echo Form::open(['url' => 'admin/soaljawabans']); ?>

              <?php endif; ?>
              <?php echo Form::hidden('jenis_bantuan_id', $jenisbantuan->id); ?>

              <div class="form-group">
                <?php echo Form::label('soal', 'Soal'); ?>

                <?php echo Form::text('soal', null, ['class' => 'form-control','placeholder' => 'Soal']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('bobot', 'bobot'); ?>

                <?php echo Form::number('bobot', null, ['class' => 'form-control','placeholder' => 'Bobot untuk perhitungan']); ?>

                <p class="text-muted">* Bobot yang bisa digunakkan <?php echo e($bobot); ?></p>
              </div>
              <div class="form-group">
                <?php echo Form::label('tipe', 'Tipe'); ?>

                <?php echo Form::select('tipe',$tipes, null, ['class' => 'form-control','placeholder' => '--Pilih Tipe--']); ?>

                <p class="text-muted">* benefit = semakin besar nilai yang dimasukkan penduduk maka semakin baik<br>
                  * cost = semakin kecil nilai yang dimasukkan penduduk maka semakin baik</p>
              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="<?php echo e(route('soaljawabans.index')); ?>" class="btn btn-secondary" >back</a>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <?php if(!empty($soaljawaban)): ?>
            <div class="col-8">
            <div class="card">
              <!-- /.card-header -->
              <div class="card p-2">
                <div class="card-header">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_jawabans')): ?>
                  <div><a class="btn btn-primary" href="<?php echo e(url('admin/soaljawabans/'.$soaljawaban->id.'/add-jawaban')); ?>">Add New</a></div>
                  <?php endif; ?>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover table-fixed-head">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Jawaban</th>
                        <th>Nilai</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_jawabans', 'delete_jawabans')): ?>
                        <th>Action</th>
                        <?php endif; ?>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $soaljawaban->jawabans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($jawaban->id); ?></td>
                          <td><?php echo e($jawaban->jawaban); ?></td>
                          <td><?php echo e($jawaban->nilai); ?></td>
                          <td><?php echo e($jawaban->created_at); ?></td>
                          <td><?php echo e($jawaban->updated_at); ?></td>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_jawabans', 'delete_jawabans')): ?>
                          <td class="row w-100">
                          <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(url('admin/soaljawabans/'.$soaljawaban->id.'/edit-jawaban/'.$jawaban->id)); ?>" role="button">
                          <i class="fa fa-fw fa-pen" aria-hidden="true"></i>
                          Edit</a>
                          <?php echo Form::open(['url' => 'admin/soaljawabans/'.$soaljawaban->id.'/delete-jawaban/'.$jawaban->id,'class'=> 'delete']); ?>

                          <?php echo Form::hidden('_method', 'DELETE'); ?>

                            <button type="submit" class="btn btn-danger btn-sm">
                              <i class="fa fa-fw fa-trash" aria-hidden="true"></i>Delete
                            </button>
                          <?php echo Form::close(); ?>

                          </td>
                          <?php endif; ?>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                            <td colspan="5">No Records</td>
                          </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                  
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        <?php endif; ?>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/soaljawabans/form.blade.php ENDPATH**/ ?>