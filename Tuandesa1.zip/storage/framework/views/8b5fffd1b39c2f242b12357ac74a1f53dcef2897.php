
<?php $__env->startSection('headTitle',__('admin.soaljawabans')); ?>
<?php 
  $jenisbantuan_id = app('request')->input('jenis_bantuan')??$jenisbantuan->id;
?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e(__('admin.soaljawabans')); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><?php echo e(__('admin.soaljawabans')); ?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="row">
          <div class="col-12">
            <div class="card">
              <!-- /.card-header -->
              <div class="card p-2">
                <div class="card-header">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_soaljawabans')): ?>
                  <div class="d-flex">
                    <a class="btn btn-success" href="<?php echo e(url('admin/soaljawabans/create?jenis_bantuan='.$jenisbantuan_id)); ?>">Add New</a>
                    <?php $__currentLoopData = $jenisbantuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo Form::open(['url' => route('soaljawabans.index'), 'method' => 'GET']); ?>

                        <?php echo Form::hidden('jenis_bantuan', $item->id); ?>

                        <button type="submit" class="btn btn-primary mx-1"><?php echo e($item->name); ?></button>
                      <?php echo Form::close(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  <?php endif; ?>
                  <div class="card-tools">
                    <div class="input-group input-group-sm" style="width: 150px;">
                      <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                      <div class="input-group-append">
                        <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover table-fixed-head">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Soal</th>
                        <th>Bobot</th>
                        <th>Tipe</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_soaljawabans', 'delete_soaljawabans')): ?>
                        <th>Action</th>
                        <?php endif; ?>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $soaljawabans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soaljawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($soaljawaban->id); ?></td>
                          <td><?php echo e($soaljawaban->soal); ?></td>
                          <td><?php echo e($soaljawaban->bobot); ?></td>
                          <td><?php echo e($soaljawaban->getTipes($soaljawaban->tipe)); ?></td>
                          <td><?php echo e($soaljawaban->created_at); ?></td>
                          <td><?php echo e($soaljawaban->updated_at); ?></td>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_soaljawabans', 'delete_soaljawabans')): ?>
                          <td class="row w-100">
                          <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(url('admin/soaljawabans/'.$soaljawaban->id.'/edit')); ?>" role="button">
                            <i class="fa fa-fw fa-pen" aria-hidden="true"></i>
                            Edit</a>
                          <?php echo Form::open(['url' => 'admin/soaljawabans/'.$soaljawaban->id,'class'=> 'delete']); ?>

                          <?php echo Form::hidden('_method', 'DELETE'); ?>

                            <button type="submit" class="btn btn-danger btn-sm">
                              <i class="fa fa-fw fa-trash" aria-hidden="true"></i>Delete
                            </button>
                          <?php echo Form::close(); ?>

                          </td>
                          <?php endif; ?>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                            <td colspan="5">No Records</td>
                          </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                  
                </div>
              </div>
              <div class="card-footer">
                <?php echo e($soaljawabans->links()); ?>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/soaljawabans/index.blade.php ENDPATH**/ ?>