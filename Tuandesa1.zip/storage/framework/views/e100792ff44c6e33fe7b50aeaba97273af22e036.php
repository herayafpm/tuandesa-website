
<?php $__env->startSection('headTitle',$zakat->name); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('vendor/adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">   
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1><?php echo e($zakat->name); ?></h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo Form::model($zakatamil, ['url' => route('profile.zakat',$zakat->id),'method' => 'PUT','id' => 'formZakat']); ?>

              <?php echo Form::hidden('id'); ?>

              <?php echo Form::hidden('zakat_id', $zakat->id); ?>

              <div class="form-group">
                <?php echo Form::label('dusun', 'Dusun'); ?>

                <select class="form-control" name="dusun" id="dusun">
                  <?php for($i = 1; $i <= $jumlahdusun; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php if(!empty($zakatamil) &&$i == $zakatamil->dusun): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="form-group">
                <?php echo Form::label('beras', 'Beras'); ?>

                <?php echo Form::text('beras', $zakatamil->beras ?? null, ['id' => 'beras','class' => 'form-control', 'data-inputmask'=> "'alias':'currency'",'digits'=>'0','allowMinus'=>'false','showMaskOnFocus'=>'false','showMaskOnHover'=>'false']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('uang', 'Uang'); ?>

                <?php echo Form::text('uang', $zakatamil->uang ?? null, ['id' => 'uang','class' => 'form-control','data-inputmask'=> "'alias':'currency'",'digits'=>'0','allowMinus'=>'false','showMaskOnFocus'=>'false','showMaskOnHover'=>'false']); ?>

              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-secondary" >back</a>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(URL::asset('vendor/adminlte/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/adminlte/plugins/inputmask/jquery.inputmask.bundle.js')); ?>"></script>
<script>
  $(function(){
    $('#beras').inputmask({
      removeMaskOnSubmit: true,
      prefix: ' Kg '
    });
    $('#uang').inputmask({
      removeMaskOnSubmit: true,
      prefix: ' Rp '
    });
  })

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/profiles/form_zakat.blade.php ENDPATH**/ ?>