
<?php $__env->startSection('headTitle',__('admin.profile')); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e(__('admin.profile'). ' '.$user->username); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><?php echo e(__('admin.profile')); ?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                <img class="profile-user-img img-fluid img-circle" src="<?php echo e(url($user->photo)); ?>" alt="User profile picture">
                </div>

              <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>
              <p class="text-muted text-center"><?php echo e($user->username); ?></p>

              <p class="text-muted text-center"><?php echo e($user->getRoleNames()[0]); ?></p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                  <b>Aduan</b> <a class="float-right"><?php echo e($user->aduans->count()); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Pelayanan</b> <a class="float-right"><?php echo e($user->pelayanans->count()); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Bantuan</b> <a class="float-right"><?php echo e($user->pelayanans->count()); ?></a>
                  </li>
                </ul>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-body">
                <div class="float-right">
                  <a class="btn btn-secondary btn-sm" href="<?php echo e(route('users.index')); ?>" role="button">
                    Back</a>
                  <a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/users/'.$user->id.'/edit')); ?>" role="button">
                    <i class="fa fa-fw fa-pen" aria-hidden="true"></i>
                    Edit</a>
                </div>
                <div class="form-group">
                  <?php echo Form::label('email', 'Email'); ?>

                  <?php echo Form::text('email', $user->email, ['class' => 'form-control','placeholder' => 'Email','readonly'=> true]); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('ttl', 'Tempat Tanggal Lahir'); ?>

                  <?php echo Form::text('ttl', $user->ttl, ['class' => 'form-control','placeholder' => 'Tempat Tanggal Lahir','readonly'=> true]); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('alamat', 'Alamat'); ?>

                  <?php echo Form::textarea('alamat', $user->address, ['class' => 'form-control','placeholder' => 'Alamat','readonly'=> true]); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('no_hp', 'NO HP'); ?>

                  <?php echo Form::text('no_hp', $user->no_hp, ['class' => 'form-control','placeholder' => 'NO HP','readonly'=> true]); ?>

                </div>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/users/show.blade.php ENDPATH**/ ?>