
<?php $__env->startSection('headTitle','Pembagian '.$zakat->name); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('vendor/adminlte/plugins/select2/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e('Pembagian '.$zakat->name); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('zakats.show',$zakat->id)); ?>">Back</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo Form::open(['url' => 'admin/zakats/'.$zakat->id.'/pembagian']); ?>

              <?php echo Form::hidden('zakat_id', $zakat->id); ?>

              <div class="form-group">
                <?php echo Form::label('user', 'Penerima Zakat'); ?>

                <?php echo SelectUser::getSelect($users,null,['class' => 'form-control select-2','multiple' => true, 'id' => 'user','name' => 'user_id[]','placeholder' => '--Pilih User--']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('presentase_user', 'Presentase Penerima Zakat'); ?>

                <?php echo Form::number('presentase_user', null,['placeholder'=> 'Isikan presentase pembagian user','class' => 'form-control','max'=>'100','min'=> '0']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('amil', 'Penerima Amil'); ?>

                <?php echo SelectUser::getSelect($amils,null,['class' => 'form-control select-2-amil','multiple' => true, 'id' => 'amil','name' => 'amil_id[]','placeholder' => '--Pilih Amil--']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('presentase_amil', 'Presentase Penerima Amil'); ?>

                <?php echo Form::number('presentase_amil', null,['placeholder'=> 'Isikan presentase pembagian amil','class' => 'form-control','max'=>'100','min'=> '0']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('fisabililah', 'Penerima Fisabilillah (Sisa Pembulatan)'); ?>

                <?php echo SelectUser::getSelect($users,null,['class' => 'form-control select-2-fisabililah','multiple' => true, 'id' => 'fisabililah','name' => 'fisabililah_id[]','placeholder' => '--Pilih Fisabililah--']); ?>

              </div>
              <div class="form-footer pt-2 border-top">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="<?php echo e(route('zakats.index')); ?>" class="btn btn-secondary" >back</a>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
 <script src="<?php echo e(URL::asset('vendor/adminlte/plugins/select2/js/select2.min.js')); ?>"></script>
 <script>
    $(function(){
      $('.select-2').select2({
        placeholder: $('.select-2').attr('placeholder'),
        allowClear: true
      })
      $('.select-2-amil').select2({
        placeholder: $('.select-2-amil').attr('placeholder'),
        allowClear: true
      })
      $('.select-2-fisabililah').select2({
        placeholder: $('.select-2-fisabililah').attr('placeholder'),
        allowClear: true
      })
    })
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/zakats/form_pembagian.blade.php ENDPATH**/ ?>