
<?php
    $formTitle = !empty($user)?'Update':'New'
?>
<?php $__env->startSection('headTitle',__('admin.datausers').' '.$formTitle); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/admin/plugins/select2/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e($formTitle); ?> <?php echo e(__('admin.datausers')); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/users')); ?>"><?php echo e(__('admin.datausers')); ?></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row mt-2">
        <div class="col">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->make('admin.partials.flash',['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if(!empty($user)): ?>
                  <?php echo Form::model($user, ['url' => ['admin/users',$user->id],'method' => 'PUT','enctype' => 'multipart/form-data']); ?>

                  <?php echo Form::hidden('id'); ?>

              <?php else: ?>
                  <?php echo Form::open(['url' => 'admin/users', 'enctype' => 'multipart/form-data']); ?>

              <?php endif; ?>
              <div class="form-group">
                <?php echo Form::label('username', 'Username'); ?>

                <?php echo Form::text('username', null, ['class' => 'form-control','placeholder' => 'Username']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('name', 'Nama Lengkap'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control','placeholder' => 'Nama Lengkap']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('email', 'Email'); ?>

                <?php echo Form::text('email', null, ['class' => 'form-control','placeholder' => 'Email']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('ttl', 'Tempat Tanggal Lahir'); ?>

                <?php echo Form::text('ttl', null, ['class' => 'form-control','placeholder' => 'Tempat Tanggal Lahir']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('alamat', 'Alamat'); ?>

                <?php echo Form::textarea('address', null, ['class' => 'form-control','placeholder' => 'Alamat']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('no_hp', 'NO HP'); ?>

                <?php echo Form::text('no_hp', null, ['class' => 'form-control','placeholder' => 'NO HP']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('role', 'Status'); ?>

                <?php echo Form::select('roles', $roles,null,  ['class' => 'form-control','placeholder' => '--Pilih Status Pengguna--']); ?>

              </div>
              <?php if(empty($user)): ?>
                <div class="form-group">
                  <?php echo Form::label('password', 'Password'); ?>

                  <?php echo Form::input('password', 'password', config('app.default_pass'),['class' => 'form-control','placeholder' => '--Password--']); ?>

                  <p class="text-muted">Password default: <?php echo e(config('app.default_pass')); ?></p>
                </div>
              <?php endif; ?>
              <div class="form-group">
                <?php echo Form::label('photo', 'Foto Profil'); ?>

                <?php echo Form::file('photo', ['class' => 'form-control-file','placeholder' => 'Foto Profil']); ?>

                <p class="text-muted">Kosongi jika tidak ingin diubah atau tetap default</p>
              </div>
              <div class="form-footer pt-2 border-top">
                <a name="" id="" class="btn btn-secondary" href="<?php echo e(route('users.index')); ?>" role="button">Back</a>
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
              <?php echo Form::close(); ?>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tuandesa1\resources\views/admin/users/form.blade.php ENDPATH**/ ?>