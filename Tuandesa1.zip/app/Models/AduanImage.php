<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AduanImage extends Model
{
     protected $fillable = [
        'aduan_id',
        'path'
    ];
}
