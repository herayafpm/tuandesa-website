<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BantuanImage extends Model
{
    protected $fillable = [
        'bantuan_id',
        'path'
    ];
}
